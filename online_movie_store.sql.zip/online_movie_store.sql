-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 04, 2014 at 11:09 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `online_movie_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(2) NOT NULL AUTO_INCREMENT,
  `email_address` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email_address`, `password`) VALUES
(1, 'hemel014@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b'),
(3, 'nasif@yahoo.com', '827ccb0eea8a706c4c34a16891f84e7b');

-- --------------------------------------------------------

--
-- Table structure for table `bangla_awarded_movies`
--

CREATE TABLE IF NOT EXISTS `bangla_awarded_movies` (
  `am_id` int(2) NOT NULL AUTO_INCREMENT,
  `a_movie_name` varchar(40) NOT NULL,
  `year` varchar(20) NOT NULL,
  `awards_type` varchar(40) NOT NULL,
  PRIMARY KEY (`am_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `bangla_awarded_movies`
--

INSERT INTO `bangla_awarded_movies` (`am_id`, `a_movie_name`, `year`, `awards_type`) VALUES
(1, 'Matir Moyna', '2002-08-12', 'National Film Award'),
(2, 'Shyamol Chhaya', '2005-05-30', 'National Film Award'),
(3, 'Nirontor', '2007-09-08', 'National Film Award'),
(4, 'Swopnodanay', '2003-06-07', 'National Film Award'),
(6, 'Britter Baire', '2009-07-03', 'National Film Award'),
(7, 'Third Person Singular Number', '2010-01-21', 'National Film Award'),
(8, 'Ghetuputra Kamola', '2012-06-12', 'National Film Award'),
(9, 'Abohomaan', '2000-12-04', 'National Film Award'),
(10, 'Annapurnar Mandir', '1954-06-07', 'National Film Award'),
(11, 'Pather Panchali', '1955-02-03', 'National Film Award'),
(12, 'Kabuliwala', '1957-08-09', 'National Film Award'),
(13, 'Ek Din Ratre', '1958-07-04', 'National Film Award'),
(14, 'Harano Sur', '1957-12-03', 'National Film Award'),
(15, 'Raja Rammohun', '1959-07-08', 'National Film Award'),
(16, 'Palanka', '1961-05-06', 'National Film Award'),
(17, 'asd', '2013-07-01', 'National Film Award');

-- --------------------------------------------------------

--
-- Table structure for table `bangla_latest_released`
--

CREATE TABLE IF NOT EXISTS `bangla_latest_released` (
  `l_id` int(4) NOT NULL AUTO_INCREMENT,
  `l_m_name` varchar(30) NOT NULL,
  `director_name` varchar(30) NOT NULL,
  `released_date` varchar(20) NOT NULL,
  PRIMARY KEY (`l_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `bangla_latest_released`
--

INSERT INTO `bangla_latest_released` (`l_id`, `l_m_name`, `director_name`, `released_date`) VALUES
(1, 'Maach Mishti & More', 'Mainak Bhaumik', '2013-02-02'),
(2, 'Misti Cheler Dustu Buddhi', 'Partha Sarathi Manna', '2013-04-04'),
(3, 'Honeymoon', 'Arup Bhanja', '2013-07-01'),
(4, 'Shunyo Awnko', 'Goutam Ghose', '2013-01-02'),
(5, 'Black Mail', 'Surya Saha', '2013-01-11'),
(6, 'Porir Swapno', 'Shyamal Bose', '2013-02-01'),
(7, 'Aajker Sangsar', 'Srikanta Ghosh', '2013-02-01'),
(8, 'Damadol', 'Manoj Michigan', '2013-02-06'),
(9, 'Kidnapper', 'Rupak Majumdar', '2013-03-04'),
(10, 'Panga Nibi Na Sala', 'Prince', '2013-03-05'),
(11, 'Hawa Badal', 'Parambrata Chatterjee', '2013-03-08'),
(12, 'Jigyasa Chinho', 'Subharanjan Roy', '2013-04-06'),
(13, 'Shabdo', 'Kaushik Ganguly', '2013-04-12'),
(14, 'Holud Pakhir Dana', 'Kanoj Das', '2013-04-13'),
(15, 'Rocky', 'Sujit Mondal', '2013-04-16');

-- --------------------------------------------------------

--
-- Table structure for table `bangla_old_movies`
--

CREATE TABLE IF NOT EXISTS `bangla_old_movies` (
  `b_o_id` int(4) NOT NULL AUTO_INCREMENT,
  `b_o_movie_name` varchar(40) NOT NULL,
  `director_name` varchar(30) NOT NULL,
  `released_date` varchar(20) NOT NULL,
  PRIMARY KEY (`b_o_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `bangla_old_movies`
--

INSERT INTO `bangla_old_movies` (`b_o_id`, `b_o_movie_name`, `director_name`, `released_date`) VALUES
(1, 'Dena Paona ', 'Premankur Atarthi', '1931-06-02'),
(2, 'Jamai Shashthi', 'Amar Chowdhury', '1931-09-12'),
(3, 'Jor Barat', 'Jyotish Bandyopadhyay', '1931-08-31'),
(4, 'Biraha', 'Tinkari Chakraborty', '1943-03-14'),
(5, 'Debdas', 'Pramathesh Barua', '1943-08-09'),
(6, 'Khasdakhal', 'Rameshchandra Dutta', '1944-07-08'),
(7, 'Khasdakhal', 'Rameshchandra Dutta', '1944-07-08'),
(8, 'Patalpuri', 'Priyanath Gangopadhyay', '1945-09-02'),
(9, 'Ratkana', 'Jatin Das', '1954-06-03'),
(10, 'Shesh Patra', 'Kalipada Das', '1954-09-07'),
(11, 'Swayambara', 'K. Bhushan', '1976-03-31'),
(12, 'Sorry Madam', 'Dilip Bose', '1963-09-05'),
(13, 'Kancher Swarga', 'Yatrik', '1976-08-04'),
(14, 'Suryasnan', 'Ajoy Kumar', '1978-05-22'),
(15, 'Shasti', 'Daya Bhai', '1987-08-18');

-- --------------------------------------------------------

--
-- Table structure for table `bangla_popular_movies`
--

CREATE TABLE IF NOT EXISTS `bangla_popular_movies` (
  `p_id` int(3) NOT NULL AUTO_INCREMENT,
  `p_movie_name` varchar(30) NOT NULL,
  `viewers_rating` varchar(30) NOT NULL,
  `released_date` varchar(20) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `bangla_popular_movies`
--

INSERT INTO `bangla_popular_movies` (`p_id`, `p_movie_name`, `viewers_rating`, `released_date`) VALUES
(3, 'The Big ', '✦ ✦ ✦ ✦ ', '1963-01-03'),
(15, 'Maach Mishti & More', '✦✦✦✦✦✦ ', '2011-03-21'),
(5, 'Distant Thunder', '✦✦✦ ', '1973-11-04'),
(7, 'Bhooter Bhabishyat', '✦✦✦ ', '2012-08-03'),
(8, 'Teen Kanya', '✦✦✦✦✦✦✦ ', '1961-03-09'),
(9, 'The Middleman', '✦✦✦✦✦✦✦✦✦ ', '1976-10-09'),
(11, 'The Adversary', '✦ ✦ ✦ ✦ ✦ ✦ ', '1970-03-03'),
(12, 'The Stranger', '✦ ✦ ✦ ', '1991-03-19'),
(13, 'The Adventures of Goopy and Ba', '✦ ✦ ', '1969-08-12'),
(17, 'Chorabali', '✦✦✦✦✦✦ ', '2012-06-12'),
(18, 'Chaya-Chobi', '✦✦✦✦✦✦✦✦✦', '2012-08-12'),
(19, 'Top Hero', '✦✦✦✦✦✦✦✦✦', '2012-03-23'),
(20, 'Television (film)', '✦✦✦✦✦✦✦✦✦', '2012-07-09'),
(21, 'Na Manush', '✦✦✦✦✦✦', '2012-09-30'),
(22, 'Hello Amit', '✦✦✦ ', '2012-02-02'),
(23, 'Ghetuputra Kamola', '✦✦✦✦✦✦✦✦', '2012-03-25'),
(24, 'Runaway', '✦✦✦✦✦✦✦✦', '2012-07-01'),
(25, 'Dehorokkhi', '✦✦✦✦✦✦✦✦✦', '2013-02-16'),
(26, 'Onnorokom Bhalobasha', '✦✦✦✦✦✦✦', '2013-04-10'),
(27, 'Devdas', '✦✦✦✦✦✦', '2013-04-03'),
(28, 'Simanaheen', '✦✦✦✦✦✦✦✦✦', '2013-05-20'),
(29, 'Moner Ghore Boshot Kore', '✦✦✦✦✦✦✦✦✦', '2011-08-11'),
(30, 'Beili Road', '✦✦✦✦✦✦', '2011-07-01'),
(31, 'Amar Bondhu Rashed', '✦✦✦✦✦✦✦✦✦', '2011-02-13'),
(32, 'Khokababu', '✦✦✦✦✦', '2012-04-05'),
(33, '100% Love', '✦✦✦✦', '2012-03-15'),
(34, 'Le Halua Le', '✦✦✦✦✦', '2012-06-17'),
(35, 'Jaaneman', '✦✦✦✦✦✦', '2012-09-14'),
(36, 'Hemlock Society', '✦✦✦✦✦✦', '2012-05-27'),
(37, 'Paglu 2', '✦✦✦✦', '2012-05-12'),
(38, 'Challenge 2', '✦✦✦✦✦✦✦', '2012-03-07');

-- --------------------------------------------------------

--
-- Table structure for table `bangla_upcoming_movies`
--

CREATE TABLE IF NOT EXISTS `bangla_upcoming_movies` (
  `up_id` int(2) NOT NULL AUTO_INCREMENT,
  `up_movie_name` varchar(30) NOT NULL,
  `released_date` varchar(20) NOT NULL,
  PRIMARY KEY (`up_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bangla_upcoming_movies`
--


-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `m_id` int(2) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email_address` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `confirm_password` varchar(32) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `gender` varchar(20) NOT NULL,
  PRIMARY KEY (`m_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`m_id`, `first_name`, `last_name`, `email_address`, `password`, `confirm_password`, `dob`, `address`, `gender`) VALUES
(1, 'Arman', 'Ahmed', 'hemel014@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '827ccb0eea8a706c4c34a16891f84e7b', '07/10/2013', ' Dhaka', 'male'),
(2, 'nasif', 'shawkat', 'nasif@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '827ccb0eea8a706c4c34a16891f84e7b', '07/17/2013', ' ', 'male'),
(6, 'sonet', 'rayhan', 'sonet@yahoo.com', '827ccb0eea8a706c4c34a16891f84e7b', '827ccb0eea8a706c4c34a16891f84e7b', '08/01/2013', ' ', 'male');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE IF NOT EXISTS `order` (
  `o_id` int(2) NOT NULL AUTO_INCREMENT,
  `m_id` int(2) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email_address` varchar(52) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(50) NOT NULL,
  `payment_method` varchar(30) NOT NULL,
  PRIMARY KEY (`o_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`o_id`, `m_id`, `first_name`, `last_name`, `email_address`, `phone_no`, `address`, `country`, `payment_method`) VALUES
(1, 1, 'asdasd', 'adasd', 'hemel014@gmail.com', '123456678', 'dhaka', 'BD', 'cash_on_delevery'),
(2, 6, 'sonet', 'rayhan', 'sonet@yahoo.com', '01966498541', 'narayangonj', 'BD', 'cash_on_delevery');
